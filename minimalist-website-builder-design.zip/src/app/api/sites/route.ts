import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { sites } from "@/db/schema";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export const dynamic = "force-dynamic";

const ALLOWED_TEMPLATES = ["essential", "editorial", "folio"] as const;
type Template = (typeof ALLOWED_TEMPLATES)[number];

const SECTION_TYPES = ["hero", "about", "features", "contact"] as const;

interface Section {
  type: (typeof SECTION_TYPES)[number];
  heading: string;
  body: string;
  items?: string[];
}

function isValidHex(value: unknown): value is string {
  return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value);
}

function isSection(value: unknown): value is Section {
  if (typeof value !== "object" || value === null) return false;
  const s = value as Record<string, unknown>;
  if (!SECTION_TYPES.includes(s.type as never)) return false;
  if (typeof s.heading !== "string") return false;
  if (typeof s.body !== "string") return false;
  if (s.items !== undefined && !Array.isArray(s.items)) return false;
  if (Array.isArray(s.items) && !s.items.every((i) => typeof i === "string")) return false;
  return true;
}

function slugify(text: string) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

async function generateSlug(title: string) {
  const base = slugify(title) || "site";
  for (let attempt = 0; attempt < 5; attempt++) {
    const suffix = randomUUID().split("-")[0];
    const slug = `${base}-${suffix}`;
    const existing = await db.select({ id: sites.id }).from(sites).where(eq(sites.slug, slug));
    if (existing.length === 0) return slug;
  }
  return `${base}-${Date.now()}`;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body || typeof body !== "object") {
      return NextResponse.json({ error: "Invalid body" }, { status: 400 });
    }

    const title = typeof body.title === "string" ? body.title.trim() : "";
    const tagline = typeof body.tagline === "string" ? body.tagline.trim() : "";
    const template = ALLOWED_TEMPLATES.includes(body.template as Template) ? (body.template as Template) : "essential";
    const accentColor = isValidHex(body.accentColor) ? body.accentColor : "#0f172a";
    const sections = Array.isArray(body.sections) && body.sections.every(isSection) ? body.sections : [];

    if (!title || title.length > 200) {
      return NextResponse.json({ error: "Title is required and must be under 200 characters" }, { status: 400 });
    }

    const slug = await generateSlug(title);

    const [site] = await db
      .insert(sites)
      .values({
        slug,
        title,
        tagline,
        template,
        accentColor,
        sections,
        published: true,
      })
      .returning({ id: sites.id, slug: sites.slug });

    return NextResponse.json(site, { status: 201 });
  } catch (error) {
    console.error("Failed to create site:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
