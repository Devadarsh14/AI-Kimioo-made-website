import { notFound } from "next/navigation";
import { db } from "@/db";
import { sites } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { SiteRenderer } from "@/components/SiteRenderer";

export const dynamic = "force-dynamic";

export default async function SitePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const rows = await db
    .select()
    .from(sites)
    .where(and(eq(sites.slug, slug), eq(sites.published, true)));

  const site = rows[0];

  if (!site) {
    notFound();
  }

  return (
    <SiteRenderer
      site={{
        slug: site.slug,
        title: site.title,
        tagline: site.tagline,
        template: site.template,
        accentColor: site.accentColor,
        sections: Array.isArray(site.sections) ? site.sections : [],
      }}
    />
  );
}
