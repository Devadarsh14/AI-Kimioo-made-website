import Link from "next/link";
import { db } from "@/db";
import { sites } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const recentSites = await db
    .select({
      slug: sites.slug,
      title: sites.title,
      template: sites.template,
    })
    .from(sites)
    .where(eq(sites.published, true))
    .orderBy(desc(sites.createdAt))
    .limit(6);

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <header className="flex items-center justify-between px-6 py-5 md:px-10">
        <Link href="/" className="text-lg font-semibold tracking-tight">
          Sprout
        </Link>
        <nav className="flex items-center gap-6 text-sm">
          <a href="#how" className="text-slate-600 hover:text-slate-900">
            How it works
          </a>
          <Link
            href="/builder"
            className="rounded-full bg-slate-900 px-4 py-2 text-white transition-transform hover:scale-[1.02]"
          >
            Start building
          </Link>
        </nav>
      </header>

      <main>
        <section className="px-6 pt-20 pb-24 md:px-10 md:pt-28 md:pb-32">
          <div className="mx-auto max-w-3xl text-center">
            <p className="text-sm font-medium uppercase tracking-[0.12em] text-slate-500">
              Minimalist website builder
            </p>
            <h1 className="mt-6 text-[clamp(2.5rem,6vw,4.5rem)] font-semibold leading-[1.05] tracking-tight text-slate-950">
              Build a calm, focused website in minutes.
            </h1>
            <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-slate-600">
              No clutter. No endless options. Answer a few prompts, pick a clean
              style, and publish a site that puts your message first.
            </p>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <Link
                href="/builder"
                className="rounded-full bg-slate-900 px-8 py-3.5 text-base font-medium text-white transition-transform hover:scale-[1.02]"
              >
                Create your site
              </Link>
              <a
                href="#recent"
                className="rounded-full border border-slate-200 px-8 py-3.5 text-base font-medium text-slate-700 transition-colors hover:border-slate-300"
              >
                See examples
              </a>
            </div>
          </div>
        </section>

        <section id="how" className="border-t border-slate-100 px-6 py-20 md:px-10 md:py-28">
          <div className="mx-auto max-w-5xl">
            <h2 className="text-center text-sm font-medium uppercase tracking-[0.12em] text-slate-500">
              Three simple steps
            </h2>
            <div className="mt-12 grid gap-8 md:grid-cols-3">
              <Step number="1" title="Name it" body="Tell us your site title, tagline, and the mood you want." />
              <Step number="2" title="Style it" body="Choose a minimalist template and an accent color that feels right." />
              <Step number="3" title="Publish it" body="Add your sections, preview the result, and share your link." />
            </div>
          </div>
        </section>

        {recentSites.length > 0 && (
          <section id="recent" className="border-t border-slate-100 px-6 py-20 md:px-10 md:py-28">
            <div className="mx-auto max-w-5xl">
              <h2 className="text-center text-sm font-medium uppercase tracking-[0.12em] text-slate-500">
                Recently published
              </h2>
              <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {recentSites.map((site) => (
                  <Link
                    key={site.slug}
                    href={`/s/${site.slug}`}
                    className="group rounded-2xl border border-slate-100 bg-slate-50/50 p-6 transition-transform hover:-translate-y-1"
                  >
                    <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                      {site.template}
                    </p>
                    <h3 className="mt-2 text-lg font-semibold tracking-tight group-hover:opacity-70">
                      {site.title}
                    </h3>
                    <p className="mt-3 text-sm text-slate-500">View site →</p>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>

      <footer className="border-t border-slate-100 px-6 py-10 text-center text-sm text-slate-500 md:px-10">
        © {new Date().getFullYear()} Sprout. Minimalist websites, made simple.
      </footer>
    </div>
  );
}

function Step({ number, title, body }: { number: string; title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-white p-8">
      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-900 text-sm font-semibold text-white">
        {number}
      </span>
      <h3 className="mt-6 text-xl font-semibold tracking-tight">{title}</h3>
      <p className="mt-3 leading-relaxed text-slate-600">{body}</p>
    </div>
  );
}
