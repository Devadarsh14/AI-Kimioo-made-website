"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { SiteRenderer, RenderSite } from "@/components/SiteRenderer";

const TEMPLATES = [
  {
    id: "essential",
    name: "Essential",
    desc: "Clean, centered, and calm.",
  },
  {
    id: "editorial",
    name: "Editorial",
    desc: "Refined typography with classic spacing.",
  },
  {
    id: "folio",
    name: "Folio",
    desc: "Bold contrast for portfolios.",
  },
] as const;

const ACCENTS = [
  "#0f172a",
  "#be123c",
  "#15803d",
  "#0369a1",
  "#7c3aed",
  "#b45309",
] as const;

const SECTION_META: Record<
  string,
  { label: string; defaultHeading: string; defaultBody: string }
> = {
  hero: {
    label: "Hero",
    defaultHeading: "",
    defaultBody: "",
  },
  about: {
    label: "About",
    defaultHeading: "About",
    defaultBody: "Share a little about who you are and what you do.",
  },
  features: {
    label: "Features",
    defaultHeading: "What makes this special",
    defaultBody: "A few highlights that set you apart.",
  },
  contact: {
    label: "Contact",
    defaultHeading: "Get in touch",
    defaultBody: "Have a question or idea? Reach out.",
  },
};

type Section = RenderSite["sections"][number];
type TemplateId = (typeof TEMPLATES)[number]["id"];

export default function BuilderPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [title, setTitle] = useState("");
  const [tagline, setTagline] = useState("");
  const [template, setTemplate] = useState<TemplateId>("essential");
  const [accentColor, setAccentColor] = useState<string>(ACCENTS[0]);
  const [enabledSections, setEnabledSections] = useState<Record<string, boolean>>({
    about: true,
    features: true,
    contact: true,
  });
  const [sections, setSections] = useState<Section[]>([
    { type: "hero", heading: "", body: "" },
    { type: "about", heading: "About", body: "Share a little about who you are and what you do." },
    {
      type: "features",
      heading: "What makes this special",
      body: "A few highlights that set you apart.",
      items: ["Simple and fast", "Fully responsive", "Easy to update"],
    },
    { type: "contact", heading: "Get in touch", body: "Have a question or idea? Reach out." },
  ]);
  const [isPublishing, setIsPublishing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const visibleSections = useMemo(
    () => sections.filter((s) => s.type === "hero" || enabledSections[s.type]),
    [sections, enabledSections]
  );

  const previewSite: RenderSite = useMemo(
    () => ({
      slug: "preview",
      title,
      tagline,
      template,
      accentColor,
      sections: visibleSections,
    }),
    [title, tagline, template, accentColor, visibleSections]
  );

  function updateSection(type: Section["type"], patch: Partial<Section>) {
    setSections((prev) =>
      prev.map((s) => (s.type === type ? { ...s, ...patch } : s))
    );
  }

  function toggleSection(type: Exclude<Section["type"], "hero">) {
    setEnabledSections((prev) => {
      const next = { ...prev, [type]: !prev[type] };
      return next;
    });
  }

  function validateCurrentStep(): string | null {
    if (step === 1) {
      if (!title.trim()) return "Please give your site a title.";
    }
    return null;
  }

  function nextStep() {
    const err = validateCurrentStep();
    if (err) {
      setError(err);
      return;
    }
    setError(null);
    setStep((s) => Math.min(s + 1, 4));
  }

  async function publish() {
    setError(null);
    setIsPublishing(true);
    try {
      const res = await fetch("/api/sites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          tagline: tagline.trim(),
          template,
          accentColor,
          sections: visibleSections,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to publish");
      }
      router.push(`/s/${data.slug}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
      setIsPublishing(false);
    }
  }

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <header className="flex items-center justify-between border-b border-slate-100 px-6 py-4 md:px-10">
        <Link href="/" className="text-lg font-semibold tracking-tight">
          Sprout
        </Link>
        <div className="flex items-center gap-2">
          {[1, 2, 3, 4].map((n) => (
            <div
              key={n}
              className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-semibold ${
                n === step
                  ? "bg-slate-900 text-white"
                  : n < step
                  ? "bg-slate-200 text-slate-700"
                  : "bg-slate-100 text-slate-400"
              }`}
            >
              {n}
            </div>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-10 md:px-10 md:py-14">
        {error && (
          <div className="mb-6 rounded-xl border border-red-100 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}

        {step === 1 && (
          <div className="mx-auto max-w-xl">
            <p className="text-sm font-medium uppercase tracking-[0.12em] text-slate-500">
              Step 1 of 4
            </p>
            <h1 className="mt-3 text-3xl font-semibold tracking-tight">
              Name your site
            </h1>
            <p className="mt-2 text-slate-600">
              Start with the basics. You can change these later.
            </p>

            <div className="mt-8 space-y-5">
              <label className="block">
                <span className="text-sm font-medium">Site title</span>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Studio Quiet"
                  className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-lg outline-none transition-colors focus:border-slate-400"
                  maxLength={200}
                />
              </label>
              <label className="block">
                <span className="text-sm font-medium">Tagline</span>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  placeholder="A short sentence about what you do"
                  className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-lg outline-none transition-colors focus:border-slate-400"
                  maxLength={300}
                />
              </label>
            </div>

            <div className="mt-10">
              <span className="text-sm font-medium">Choose a template</span>
              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                {TEMPLATES.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTemplate(t.id)}
                    className={`rounded-2xl border p-4 text-left transition-all ${
                      template === t.id
                        ? "border-slate-900 bg-slate-50"
                        : "border-slate-100 hover:border-slate-200"
                    }`}
                  >
                    <p className="font-semibold">{t.name}</p>
                    <p className="mt-1 text-sm text-slate-500">{t.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="mx-auto max-w-xl">
            <p className="text-sm font-medium uppercase tracking-[0.12em] text-slate-500">
              Step 2 of 4
            </p>
            <h1 className="mt-3 text-3xl font-semibold tracking-tight">
              Style it
            </h1>
            <p className="mt-2 text-slate-600">
              Pick a calm accent color and the sections you need.
            </p>

            <div className="mt-8">
              <span className="text-sm font-medium">Accent color</span>
              <div className="mt-3 flex flex-wrap gap-3">
                {ACCENTS.map((color) => (
                  <button
                    key={color}
                    onClick={() => setAccentColor(color)}
                    aria-label={`Select accent color ${color}`}
                    className={`h-10 w-10 rounded-full border-2 transition-transform hover:scale-110 ${
                      accentColor === color ? "border-slate-900" : "border-transparent"
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            <div className="mt-10">
              <span className="text-sm font-medium">Sections</span>
              <div className="mt-3 space-y-2">
                {(["about", "features", "contact"] as const).map((type) => (
                  <label
                    key={type}
                    className="flex cursor-pointer items-center justify-between rounded-xl border border-slate-100 px-4 py-3 hover:bg-slate-50"
                  >
                    <span className="capitalize">{SECTION_META[type].label}</span>
                    <input
                      type="checkbox"
                      checked={enabledSections[type]}
                      onChange={() => toggleSection(type)}
                      className="h-5 w-5 accent-slate-900"
                    />
                  </label>
                ))}
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="mx-auto max-w-2xl">
            <p className="text-sm font-medium uppercase tracking-[0.12em] text-slate-500">
              Step 3 of 4
            </p>
            <h1 className="mt-3 text-3xl font-semibold tracking-tight">
              Add your content
            </h1>
            <p className="mt-2 text-slate-600">
              Keep it short. Minimalist sites work best with clear, simple words.
            </p>

            <div className="mt-8 space-y-8">
              {visibleSections.map((section) => (
                <div
                  key={section.type}
                  className="rounded-2xl border border-slate-100 bg-slate-50/50 p-5"
                >
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500">
                    {SECTION_META[section.type].label}
                  </h3>
                  <label className="mt-4 block">
                    <span className="text-sm font-medium">Heading</span>
                    <input
                      type="text"
                      value={section.heading}
                      onChange={(e) =>
                        updateSection(section.type, { heading: e.target.value })
                      }
                      placeholder={SECTION_META[section.type].defaultHeading}
                      className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 outline-none focus:border-slate-400"
                    />
                  </label>
                  <label className="mt-4 block">
                    <span className="text-sm font-medium">
                      {section.type === "features" ? "Body / intro" : "Body"}
                    </span>
                    <textarea
                      value={section.body}
                      onChange={(e) =>
                        updateSection(section.type, { body: e.target.value })
                      }
                      rows={3}
                      placeholder={SECTION_META[section.type].defaultBody}
                      className="mt-2 w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-2.5 outline-none focus:border-slate-400"
                    />
                  </label>
                  {section.type === "features" && (
                    <label className="mt-4 block">
                      <span className="text-sm font-medium">
                        Feature list (one per line)
                      </span>
                      <textarea
                        value={(section.items || []).join("\n")}
                        onChange={(e) =>
                          updateSection(section.type, {
                            items: e.target.value
                              .split("\n")
                              .map((line) => line.trim())
                              .filter(Boolean),
                          })
                        }
                        rows={4}
                        className="mt-2 w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-2.5 font-mono text-sm outline-none focus:border-slate-400"
                      />
                    </label>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {step === 4 && (
          <div>
            <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm font-medium uppercase tracking-[0.12em] text-slate-500">
                  Step 4 of 4
                </p>
                <h1 className="mt-1 text-3xl font-semibold tracking-tight">
                  Preview & publish
                </h1>
              </div>
              <button
                onClick={publish}
                disabled={isPublishing}
                className="rounded-full bg-slate-900 px-8 py-3.5 text-base font-medium text-white transition-transform hover:scale-[1.02] disabled:opacity-60"
              >
                {isPublishing ? "Publishing…" : "Publish site"}
              </button>
            </div>

            <div className="overflow-hidden rounded-2xl border border-slate-200 shadow-sm">
              <SiteRenderer site={previewSite} />
            </div>
          </div>
        )}

        <div className="mt-10 flex items-center justify-between">
          <button
            onClick={() => setStep((s) => Math.max(s - 1, 1))}
            disabled={step === 1}
            className="rounded-full px-5 py-2.5 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-50 disabled:opacity-40"
          >
            Back
          </button>
          {step < 4 && (
            <button
              onClick={nextStep}
              className="rounded-full bg-slate-900 px-6 py-2.5 text-sm font-medium text-white transition-transform hover:scale-[1.02]"
            >
              Continue
            </button>
          )}
        </div>
      </main>
    </div>
  );
}
