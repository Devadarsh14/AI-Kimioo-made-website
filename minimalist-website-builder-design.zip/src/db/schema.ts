import { pgTable, serial, varchar, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const sites = pgTable("sites", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  title: varchar("title", { length: 200 }).notNull(),
  tagline: varchar("tagline", { length: 300 }).notNull().default(""),
  template: varchar("template", { length: 50 }).notNull().default("essential"),
  accentColor: varchar("accent_color", { length: 7 }).notNull().default("#0f172a"),
  sections: jsonb("sections").notNull().default(sql`'[]'::jsonb`),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Site = typeof sites.$inferSelect;
export type NewSite = typeof sites.$inferInsert;
