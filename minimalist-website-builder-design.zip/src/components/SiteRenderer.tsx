import Link from "next/link";

export interface RenderSite {
  slug: string;
  title: string;
  tagline: string;
  template: string;
  accentColor: string;
  sections: {
    type: "hero" | "about" | "features" | "contact";
    heading: string;
    body: string;
    items?: string[];
  }[];
}

function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

export function SiteRenderer({ site }: { site: RenderSite }) {
  const template = site.template;
  const isFolio = template === "folio";
  const isEditorial = template === "editorial";

  const wrapper = cn(
    "min-h-screen flex flex-col transition-colors",
    isFolio && "bg-neutral-950 text-neutral-100",
    isEditorial && "bg-stone-50 text-stone-900 font-serif",
    !isFolio && !isEditorial && "bg-white text-slate-900"
  );

  const header = cn(
    "flex items-center justify-between px-6 py-6 md:px-10",
    isFolio && "border-b border-neutral-900",
    isEditorial && "border-b border-stone-200",
    !isFolio && !isEditorial && "border-b border-slate-100"
  );

  const navLink = cn(
    "text-sm tracking-wide hover:opacity-70 transition-opacity",
    isFolio ? "text-neutral-300" : isEditorial ? "text-stone-600" : "text-slate-600"
  );

  const hero = cn(
    "flex flex-col justify-center px-6 md:px-10",
    isFolio ? "py-24 md:py-32" : "py-20 md:py-28"
  );

  const heading = cn(
    "max-w-4xl font-semibold leading-[1.05] tracking-tight",
    isFolio ? "text-4xl md:text-6xl" : "text-4xl md:text-5xl lg:text-6xl"
  );

  const subheading = cn(
    "mt-6 max-w-2xl text-lg md:text-xl leading-relaxed",
    isFolio ? "text-neutral-400" : isEditorial ? "text-stone-600" : "text-slate-600"
  );

  const sectionBox = cn(
    "px-6 py-16 md:px-10 md:py-24",
    isFolio && "border-t border-neutral-900",
    isEditorial && "border-t border-stone-200",
    !isFolio && !isEditorial && "border-t border-slate-100"
  );

  const sectionTitle = cn(
    "text-2xl md:text-3xl font-semibold tracking-tight",
    isFolio ? "text-neutral-100" : isEditorial ? "text-stone-900" : "text-slate-900"
  );

  const bodyText = cn(
    "mt-4 max-w-2xl text-base md:text-lg leading-relaxed",
    isFolio ? "text-neutral-400" : isEditorial ? "text-stone-600" : "text-slate-600"
  );

  const mutedText = isFolio ? "text-neutral-400" : isEditorial ? "text-stone-600" : "text-slate-600";

  return (
    <div className={wrapper} style={{ ["--accent" as string]: site.accentColor } as React.CSSProperties}>
      <header className={header}>
        <Link href={`/s/${site.slug}`} className="text-lg font-semibold tracking-tight">
          {site.title}
        </Link>
        <nav className="flex items-center gap-6">
          {site.sections.map((s) =>
            s.type === "hero" ? null : (
              <a key={s.type} href={`#${s.type}`} className={navLink}>
                {s.heading}
              </a>
            )
          )}
        </nav>
      </header>

      <main className="flex-1">
        {site.sections.map((section) => {
          if (section.type === "hero") {
            return (
              <section key="hero" className={hero}>
                <h1 className={heading}>{section.heading || site.title}</h1>
                <p className={subheading}>{section.body || site.tagline}</p>
                {site.sections.length > 1 && (
                  <div className="mt-10">
                    <a
                      href={`#${site.sections[1]?.type}`}
                      className="inline-flex items-center justify-center rounded-full bg-[var(--accent)] px-7 py-3 text-sm font-medium text-white transition-transform hover:scale-[1.02]"
                    >
                      Explore
                    </a>
                  </div>
                )}
              </section>
            );
          }

          if (section.type === "about") {
            return (
              <section key="about" id="about" className={sectionBox}>
                <h2 className={sectionTitle}>{section.heading}</h2>
                <p className={bodyText}>{section.body}</p>
              </section>
            );
          }

          if (section.type === "features") {
            return (
              <section key="features" id="features" className={sectionBox}>
                <h2 className={sectionTitle}>{section.heading}</h2>
                <p className={bodyText}>{section.body}</p>
                {section.items && section.items.length > 0 && (
                  <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {section.items.map((item, idx) => {
                      const cardBg = isFolio
                        ? "border-neutral-800 bg-neutral-900"
                        : isEditorial
                        ? "border-stone-200 bg-stone-100/50"
                        : "border-slate-100 bg-slate-50/50";
                      const cardText = isFolio
                        ? "text-neutral-300"
                        : isEditorial
                        ? "text-stone-700"
                        : "text-slate-700";
                      return (
                        <div
                          key={idx}
                          className={cn(
                            "rounded-2xl border p-6 transition-transform hover:-translate-y-1",
                            cardBg
                          )}
                        >
                          <div className="h-2 w-2 rounded-full bg-[var(--accent)]" />
                          <p className={cn("mt-4 text-base", cardText)}>
                            {item}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>
            );
          }

          if (section.type === "contact") {
            return (
              <section key="contact" id="contact" className={sectionBox}>
                <h2 className={sectionTitle}>{section.heading}</h2>
                <p className={bodyText}>{section.body}</p>
                <a
                  href={`mailto:hello@${site.slug}.com`}
                  className={cn("mt-6 inline-block text-[var(--accent)] underline underline-offset-4 hover:opacity-70")}
                >
                  hello@{site.slug}.com
                </a>
              </section>
            );
          }

          return null;
        })}
      </main>

      <footer
        className={cn(
          "px-6 py-8 text-sm md:px-10",
          isFolio && "border-t border-neutral-900 text-neutral-500",
          isEditorial && "border-t border-stone-200 text-stone-500",
          !isFolio && !isEditorial && "border-t border-slate-100 text-slate-500"
        )}
      >
        © {new Date().getFullYear()} {site.title}. Built with Sprout.
      </footer>
    </div>
  );
}
